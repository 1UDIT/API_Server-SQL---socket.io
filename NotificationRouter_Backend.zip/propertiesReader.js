var propertiesReader = require('properties-reader');
var properties = propertiesReader('./config/Config.properties');  


// exports.properties = properties;
module.exports = properties